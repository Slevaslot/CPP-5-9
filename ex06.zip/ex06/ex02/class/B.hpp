#ifndef B_HPP
#define B_HPP
#include "../Base.hpp"
#include <iostream>

class B : public Base
{
};


#endif
