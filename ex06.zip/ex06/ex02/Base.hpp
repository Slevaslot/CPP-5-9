#ifndef BASE_HPP
#define BASE_HPP

#include <iostream>
#include <string>
#include <ctime>
#include <cstdlib>
#include <stdexcept>

class Base
{
	public:
		virtual ~Base();
};

#endif
